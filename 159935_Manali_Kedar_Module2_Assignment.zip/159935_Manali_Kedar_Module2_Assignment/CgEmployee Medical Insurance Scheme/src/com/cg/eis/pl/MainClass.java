package com.cg.eis.pl;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;
public class MainClass {
	public static void main(String[] args) throws EmployeeException, FileNotFoundException, ClassNotFoundException, IOException {
		EmployeeService employeeService = new EmployeeServiceImpl();
		for (int i = 0; i < 1; i++) {
			Employee e = new Employee();
			employeeService.getEmployeeDetails(e);
			e.setInsuranceScheme(employeeService.findInsuranceScheme(e.getSalary(),e.getDesignation()));
			if(e.getInsuranceScheme()==null) throw new EmployeeException("No Scheme Insurance Applicable");
			System.out.println("Scheme Assigned: "+ e.getInsuranceScheme()+"\n Reading Object from File");
			EmployeeServiceImpl.Serializationmethod(e);
			}
		System.out.println("Find details output");
		employeeService.findDetails("Scheme B");
		if(employeeService.deleteEmployee(1004))
			System.out.println("Employee Deleted");
		System.out.println("All empoyees are");
		employeeService.displayDetails();
		System.out.println("Sorted based on Salary");
		employeeService.sortData();
	}
}