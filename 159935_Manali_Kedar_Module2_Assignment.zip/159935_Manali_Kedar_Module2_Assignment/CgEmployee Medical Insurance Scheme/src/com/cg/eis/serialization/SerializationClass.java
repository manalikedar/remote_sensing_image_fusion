package com.cg.eis.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import com.cg.eis.bean.Employee;
public class SerializationClass {
	public static void doSerialization(File file,Employee employee) throws FileNotFoundException,IOException {
		try(ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream(file))){
//			Employee employee = new Employee(101, "Manali", "Kedar", "Programmer", 25000);
			writer.writeObject(employee);
			//			System.out.println("Object transfered to "+file);
		}
	}
	public static void doDeserialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
		try(ObjectInputStream reader = new ObjectInputStream(new FileInputStream(file))){
			Employee employee = (Employee) reader.readObject();
			System.out.println(employee);
		}
	}
}
