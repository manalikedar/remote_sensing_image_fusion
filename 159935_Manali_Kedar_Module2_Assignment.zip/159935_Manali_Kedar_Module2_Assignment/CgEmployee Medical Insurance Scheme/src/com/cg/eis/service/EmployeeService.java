package com.cg.eis.service;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
public interface EmployeeService {
	void getEmployeeDetails(Employee employee) throws EmployeeException, FileNotFoundException, ClassNotFoundException, IOException;
	String findInsuranceScheme(int salary,String Designation) ;
	void displayDetails();
	void findDetails(String insuranceScheme); 
	boolean deleteEmployee(int id);
	void sortData();
}