package com.cg.eis.service;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.serialization.SerializationClass;
public class EmployeeServiceImpl implements EmployeeService{
	private static int EMPLOYEE_ID_COUNTER=1001;
	HashMap<Integer, Employee> employees = new HashMap<>();
	@Override
	public void getEmployeeDetails(Employee employee) throws EmployeeException, FileNotFoundException, ClassNotFoundException, IOException {
		Scanner s = new Scanner(System.in);
		employee.setEmpId(EMPLOYEE_ID_COUNTER++);
		System.out.println("Enter Employee first name");
		employee.setFirstName(s.next());
		System.out.println("Enter Employee last name");
		employee.setLastName(s.next());
		System.out.println("Enter Employee Designation");
		employee.setDesignation(s.next());
		System.out.println("Enter Employee Salary");
		employee.setSalary(s.nextInt());
		addEmployee(employee);
		s.close();
	}

	@Override
	public String findInsuranceScheme(int salary, String Designation) {
		if((salary>=5000) && (salary<20000)&&Designation.toUpperCase().compareTo("System Associate".toUpperCase())==0)
			return "Scheme C";
		else if ((salary>=20000) && (salary<40000) && Designation.toUpperCase().compareTo("Programmer".toUpperCase())==0)
			return "Scheme B";
		else if((salary>=40000) && Designation.toUpperCase().compareTo("MANAGER")==0)
			return "Scheme A";
		else if((salary<5000) && Designation.toUpperCase().compareTo("CLERK")==0) 
			return "No Scheme";
		else
			return null;
	}
	public void addEmployee(Employee employee) throws FileNotFoundException, IOException, ClassNotFoundException	{
		employees.put(employee.getEmpId(), employee);
	}
	public static void Serializationmethod(Employee employee) throws FileNotFoundException, IOException, ClassNotFoundException {
		File file	= new File("D:\\Manali\\Core Java\\Employee\\Employee.txt");
		SerializationClass.doSerialization(file,employee);
		SerializationClass.doDeserialization(file);
	}
	public void findDetails(String insuranceScheme) {
		for (int key : employees.keySet()){
			if(employees.get(key).getInsuranceScheme()==insuranceScheme)
				//employees.get(key).getInsuranceScheme()==insuranceScheme)
				System.out.println(employees.get(key).toString());
		}
	}
	public boolean deleteEmployee(int id)	{
		if(employees.remove(id) != null) 
			return true;
		else
			return false;
		//	     code to delete a employee whose id is passed as parameter
	}
	@Override
	public void displayDetails() {
		for (int key : employees.keySet())
			System.out.println(employees.get(key));
	}
	@Override
	public void sortData() {
		ArrayList<Employee> list = new ArrayList<>(employees.values());
		Collections.sort(list);
		for (Employee employee : list) 
			System.out.println(employee);
	}
}