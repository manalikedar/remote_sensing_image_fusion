package com.cg.eis.bean;
import java.io.Serializable;

import com.cg.eis.exception.EmployeeException;
public class Employee implements Comparable<Employee>,Serializable{
	private int empId;
	private String firstName,lastName,designation;
	private int salary;
	private String insuranceScheme;
	public Employee(int empId, String firstName, String lastName,
			String designation, int salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.designation = designation;
		this.salary = salary;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) throws EmployeeException {
		if (salary<3000) throw new EmployeeException("Salary can't be less than 3000");
		else
			this.salary = salary;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	@Override
	public String toString() {
		return "empId=" + empId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", designation=" + designation
				+ ", salary=" + salary + ", insuranceScheme=" + insuranceScheme;
	}
	@Override
	public int compareTo(Employee o) {
		return this.salary-o.salary;
	}
}