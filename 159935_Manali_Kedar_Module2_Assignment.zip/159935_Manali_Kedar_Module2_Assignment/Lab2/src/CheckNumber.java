import java.util.Scanner;


public class CheckNumber {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a Number:");
		int num1 = s.nextInt();
		if(num1>0)
			System.out.println("Number is Positive");
		else if(num1==0)
			System.out.println("Number is neither Negative nor Positive");
		else
			System.out.println("Number is Negative");
		s.close();
	}
}
