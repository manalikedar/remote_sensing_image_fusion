package com.cg.lab2.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.lab2.beans.Gender;
import com.cg.lab2.beans.Person;
import com.cg.lab2.exceptions.NameNotFoundException;

public class PersonMain {

	public static void main(String[] args) throws NameNotFoundException, FileNotFoundException, IOException {
		Person person = new Person("Manali", "Kedar", Gender.F);
		person.PhoneNumber();
		System.out.println("\nPerson Details:\n____________\n");
		System.out.println("First Name:      "+person.getFirstName());
		System.out.println("Last Name:       "+person.getLastName());
		System.out.println("Gender:  "+person.getGender());
		System.out.println("Age:  25");
		System.out.println("Weight: 51.55");
		System.out.println("Phone Number:"+person.getPhoneNo());
		Properties projectProperties = new Properties();
		projectProperties.load(new FileInputStream(".//PersonProps.properties"));
		String projectKey1 = projectProperties.getProperty("personKey1");
		String projectKey2 = projectProperties.getProperty("personKey12");
		System.out.println(projectKey1 + " "+projectKey2);

	}

}
