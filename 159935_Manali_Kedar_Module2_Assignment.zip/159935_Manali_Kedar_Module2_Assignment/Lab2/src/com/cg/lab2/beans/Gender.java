package com.cg.lab2.beans;

public enum Gender {
	Male, Female, Unkown,M,F
}
