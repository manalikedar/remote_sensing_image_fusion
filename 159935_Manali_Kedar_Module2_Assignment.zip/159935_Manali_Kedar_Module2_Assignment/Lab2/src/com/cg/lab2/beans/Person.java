package com.cg.lab2.beans;

import java.sql.Date;
import java.util.Scanner;

import com.cg.lab2.exceptions.NameNotFoundException;

public class Person {
	private String firstName,lastName;
	private Gender gender;
	private long phoneNo;
	private Date dob;
	private int age;
	public String getFirstName() throws NameNotFoundException{
		if(firstName==null) throw new NameNotFoundException("Name does not exist");
		else
			return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() throws NameNotFoundException {
		if(lastName==null) throw new NameNotFoundException("Name Does not exist");
		else
			return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(String firstName, String lastName, Gender gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void PhoneNumber() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Phone Number:");
		this.phoneNo = s.nextLong();
		s.close();
	}
	
	
}
