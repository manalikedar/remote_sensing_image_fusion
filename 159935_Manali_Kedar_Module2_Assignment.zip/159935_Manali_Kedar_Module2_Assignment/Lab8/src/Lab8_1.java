import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class Lab8_1 {
	public static void byteStreamReadWrite(File fileFrom,File fileTo) throws IOException {
		try(BufferedInputStream srcStream= new BufferedInputStream(new FileInputStream(fileFrom))){
			try(BufferedOutputStream destStream=new BufferedOutputStream(new FileOutputStream(fileTo))){
				byte[] dataBuffer = new byte[(int) fileFrom.length()];
				srcStream.read(dataBuffer);
				String read = srcStream.toString();
				System.out.println(read);
				destStream.write(dataBuffer);
			}
		}
		System.out.println("File has Transferred");
	}
}
