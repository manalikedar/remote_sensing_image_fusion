package com.cg.banking.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.activity.InvalidActivityException;

import org.apache.log4j.Logger;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private static final Logger logger = Logger.getLogger(BankingServicesImpl.class);
	//accountTable = new HashMap<>();
	AccountDAO accountDAO = new AccountDAOImpl();
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
			if(!accountType.equals("Savings")) throw new InvalidAccountTypeException("Invalid Account Type");
			if(initBalance<1000)throw new InvalidAmountException("Invalid Amount Exception");
			try{
			Account account=accountDAO.addAccount(accountType, initBalance);
			logger.info("Account Added with account Number "+account.getAccountNo());
			return account.getAccountNo();
			}catch(SQLException e){
			logger.error(e.getMessage()+" "+e.getErrorCode()+" "+e.getCause());
		}
			throw new BankingServicesDownException("Services down");
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, SQLException, InvalidAccountTypeException, InvalidAmountException {
		try{
		Account account= accountDAO.findOne(accountNo);
		if(account==null) throw new AccountNotFoundException("Account not found");
		account.setAccountBalance(account.getAccountBalance()+amount);
		AccountDAOImpl.updateAccount(account.getAccountBalance(), accountNo);
		if(AccountDAOImpl.updateTransaction(amount, "Credit", accountNo))
		return account.getAccountBalance();
		}catch(SQLException e){
			logger.error(e.getMessage()+" "+e.getErrorCode()+" "+e.getCause());
	}
		throw new AccountNotFoundException("Acoount not found");
		
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, SQLException, InvalidAccountTypeException, InvalidAmountException, InvalidActivityException {
		Account account = accountDAO.findOne(accountNo);
		if (account==null) throw new AccountNotFoundException("No such Account exists");
		if(account.getPinNumber()==pinNumber)
			if(account.getAccountBalance()-amount>1000){
				account.setAccountBalance(account.getAccountBalance()-amount);
				AccountDAOImpl.updateAccount(account.getAccountBalance(), accountNo);
				if(AccountDAOImpl.updateTransaction(amount, "Debit", accountNo))
					return account.getAccountBalance();
			}
			else
				throw new InsufficientAmountException("Insufficient Amount");
		else
			throw new InvalidPinNumberException("Pin Does Not Match");
		throw new InvalidActivityException("Invalid Transaction");
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, SQLException, InvalidAccountTypeException, InvalidAmountException {
		try{
			Account accountTo=accountDAO.findOne(accountNoTo);
			if(accountTo==null) throw new AccountNotFoundException("To account number not found");
			Account accountFrom=accountDAO.findOne(accountNoFrom);
			if(accountFrom==null) throw new AccountNotFoundException("From account number not found");
			if(accountFrom.getPinNumber()==pinNumber)
				if(accountFrom.getAccountBalance()-transferAmount>1000){
					accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
					AccountDAOImpl.updateAccount(accountFrom.getAccountBalance(), accountNoFrom);
					AccountDAOImpl.updateTransaction(transferAmount, "Debit", accountNoFrom);
					accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
					AccountDAOImpl.updateAccount(accountTo.getAccountBalance(), accountNoTo);
					AccountDAOImpl.updateTransaction(transferAmount, "Credit", accountNoTo);
					return true;
				}
				else
					throw new InsufficientAmountException();
			else
				throw new InvalidPinNumberException();
		}catch (AccountNotFoundException e) {
			throw e;
		}catch (InsufficientAmountException e) {
			System.out.println("Insufficient Amount");
			//e.printStackTrace();
			throw e;
		}catch (InvalidPinNumberException e) {
			System.out.println("Pin does not match");
			//e.printStackTrace();
			throw e;
		}
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, SQLException, InvalidActivityException  {

		try {
			Account account;
			account = accountDAO.findOne(accountNo);
			if(account!=null)
				return account;
			else
				throw new AccountNotFoundException("Account not found");
		} catch(AccountNotFoundException e){
			System.out.println("Account not found");
			throw e;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw e;
		} catch (InvalidAccountTypeException e) {
			System.out.println("InvalidAccountType");
			e.printStackTrace();
		} catch (InvalidAmountException e) {
			System.out.println("InvalidAmount");
			e.printStackTrace();
		}
		throw new InvalidActivityException("Invalid Activity");
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException, InvalidAccountTypeException, InvalidAmountException, SQLException {

		try {
			ArrayList<Account> accountList;
			accountList = accountDAO.findAll();
			if(accountList.isEmpty()) throw new SQLException();
			return accountList;
		} catch (SQLException e) {
			System.out.println("Services down");
			logger.error(e.getMessage());
			throw e;
		}
		
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, InvalidActivityException {
		try{
			ArrayList<Transaction> accountTransactionList;
			accountTransactionList = accountDAO.findAccountTransactions(accountNo);
			if(accountTransactionList.isEmpty()) throw new AccountNotFoundException();
			return accountTransactionList;
		}catch (SQLException e) {
			System.out.println("Services down");
			logger.error(e.getMessage());
			e.printStackTrace();
		}catch (AccountNotFoundException e) {
			System.out.println("Account not found");
		}
		throw new InvalidActivityException();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException, SQLException {

		try {
			Account account;
			account = accountDAO.findOne(accountNo);
			return account.getStatus();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (InvalidAccountTypeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAmountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

}
