package com.cg.banking.services;

import java.sql.SQLException;
import java.util.List;

import javax.activity.InvalidActivityException;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface BankingServices {

	long openAccount(String accountType,float initBalance)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException, SQLException;

	float depositAmount(long accountNo,float amount)
			throws
			AccountNotFoundException,BankingServicesDownException, AccountBlockedException, SQLException, InvalidAccountTypeException, InvalidAmountException;

	float withdrawAmount(long accountNo,float amount,int pinNumber)
			throws InsufficientAmountException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException, SQLException, InvalidAccountTypeException, InvalidAmountException, InvalidActivityException;

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, SQLException, InvalidAccountTypeException, InvalidAmountException  ;

	Account getAccountDetails(long accountNo)
			throws  AccountNotFoundException,BankingServicesDownException, SQLException, InvalidAccountTypeException, InvalidAmountException, InvalidActivityException;

	List<Account> getAllAccountDetails()
			throws BankingServicesDownException, InvalidAccountTypeException, InvalidAmountException, SQLException;

	List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException, InvalidActivityException;

	public String accountStatus(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException, AccountBlockedException, SQLException;
}