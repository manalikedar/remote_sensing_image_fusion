package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;


public interface AccountDAO {
	Account addAccount(String accountType, float initBalance) throws InvalidAccountTypeException, InvalidAmountException, SQLException, BankingServicesDownException;

	Account findOne(long accountNo) throws SQLException, InvalidAccountTypeException, InvalidAmountException, AccountNotFoundException;
	
	public ArrayList<Account> findAll() throws InvalidAccountTypeException, InvalidAmountException, SQLException;
	
	public ArrayList<Transaction> findAccountTransactions(long accountNo) throws SQLException;
}