package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.util.ConnectionProvider;

public class AccountDAOImpl implements AccountDAO{
	/*private static HashMap<Long, Account> accounts=new HashMap<>();
	private static HashMap<Integer, Transaction> transactions=new HashMap<>();
	private static int ACCOUNT_ID_COUNTER=101;
	private static int TRANSACTION_ID_COUNTER=1;*/
	private static Connection conn= ConnectionProvider.getDbConnection();
	@Override
	public Account addAccount(String accountType, float initBalance) throws InvalidAccountTypeException, InvalidAmountException, SQLException, BankingServicesDownException {
		try{
			Account account = new Account(1234, accountType, "Active", initBalance);
			int accountNo=insertAccount(account);
			account.setAccountNo(accountNo);
			return account;
		}catch(SQLException e){
			throw e;
		}
	}

		@Override
		public Account findOne(long accountNo) throws SQLException, InvalidAccountTypeException, InvalidAmountException, AccountNotFoundException {

			try {
				Account account = findAccount(accountNo);
				if(account!=null)
					return account;
				else
					throw new AccountNotFoundException("Not found");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			return null;

		}
		private static int insertAccount(Account account) throws SQLException{
			try{
				conn.setAutoCommit(false);
				PreparedStatement ps1=conn.prepareStatement("INSERT INTO ASSIGNMENT_ACCOUNT values(Account_id_Seq.nextval,?,?,?,?)");
				ps1.setInt(1, account.getPinNumber());
				ps1.setString(2, account.getAccountType());
				ps1.setString(3, account.getStatus());
				ps1.setFloat(4, account.getAccountBalance());
				ps1.executeUpdate();
				conn.commit();
				PreparedStatement ps2 = conn.prepareStatement("select max(accountNo) from ASSIGNMENT_ACCOUNT");
				ResultSet rs=ps2.executeQuery();
				rs.next();
				int accountNo=rs.getInt(1);
				return accountNo;
			}
			catch(SQLException e){
				//e.printStackTrace();
				conn.rollback();
				throw e;
			}
			finally{
				conn.setAutoCommit(true);
			}
		}

		private static Account findAccount(long accountNo) throws SQLException, InvalidAccountTypeException, InvalidAmountException{
			try{
				PreparedStatement ps1=conn.prepareStatement("select * from ASSIGNMENT_ACCOUNT where accountno="+accountNo);
				ResultSet rs = ps1.executeQuery();
				rs.next();
				Account account = new Account(rs.getInt(2), rs.getString(3),	rs.getString(4), rs.getFloat(5), rs.getLong(1));
				return account;
			}catch(SQLException e){

			}
			return null;
		}
		public static boolean updateTransaction(float amount,String transactionType,long accountNo) throws SQLException{
			try{
				conn.setAutoCommit(false);
				PreparedStatement ps1=conn.prepareStatement("INSERT INTO ASSIGNMENT_transaction values(Transaction_id_Seq.nextval,?,?,?)");
				ps1.setFloat(1, amount);
				ps1.setString(2, transactionType);
				ps1.setLong(3, accountNo);
				ps1.executeUpdate();
				conn.commit();
				return true;
			}
			catch(SQLException e){
				e.printStackTrace();
				conn.rollback();
				throw e;
			}
			finally{
				conn.setAutoCommit(true);
			}
		}
		public static void updateAccount(float accountBalance,long accountNo) throws SQLException{
			try{
				conn.setAutoCommit(false);
				PreparedStatement ps1=conn.prepareStatement("UPDATE ASSIGNMENT_ACCOUNT set accountBalance="+accountBalance+"where accountNo="+accountNo);
				ps1.executeUpdate();
				conn.commit();
			}
			catch(SQLException e){
				e.printStackTrace();
				conn.rollback();
				throw e;
			}
			finally{
				conn.setAutoCommit(true);
			}
		}

		@Override
		public ArrayList<Account> findAll() throws InvalidAccountTypeException, InvalidAmountException, SQLException {

			try {
				ArrayList< Account> arrayList = new ArrayList<>();
				PreparedStatement pstmt1 = conn.prepareStatement("Select * from ASSIGNMENT_ACCOUNT");
				ResultSet accountRS;
				accountRS = pstmt1.executeQuery();

				while(accountRS.next()){
					long accountNo = accountRS.getLong(1);
					Account account= new Account(accountRS.getInt(2),accountRS.getString(3) , accountRS.getString(4), accountRS.getFloat(5), accountRS.getLong(1));
					arrayList.add(account);
				}
				return arrayList;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			}

		}

		@Override
		public ArrayList<Transaction> findAccountTransactions(long accountNo) throws SQLException {
			try {
				ArrayList< Transaction> arrayList = new ArrayList<>();
				PreparedStatement pstmt1 = conn.prepareStatement("Select * from ASSIGNMENT_TRANSACTION where accountno="+accountNo);
				ResultSet accountTransactionRS= pstmt1.executeQuery();
				while(accountTransactionRS.next()){
					//long accountNo = accountRS.getLong(1);
					Transaction transaction= new Transaction(accountTransactionRS.getInt(1), accountTransactionRS.getFloat(2), accountTransactionRS.getString(3));
					arrayList.add(transaction);
				}
				return arrayList;
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw e;
			}
		}

	}
