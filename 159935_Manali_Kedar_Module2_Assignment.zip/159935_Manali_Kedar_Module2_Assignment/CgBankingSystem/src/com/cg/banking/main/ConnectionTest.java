package com.cg.banking.main;

import com.cg.banking.util.ConnectionProvider;

public class ConnectionTest {
	public static void main(String[] args) {
		if(ConnectionProvider.getDbConnection()!=null)
			System.out.println("Connection Open");
		else
			System.out.println("Some Problem");
	}
}
