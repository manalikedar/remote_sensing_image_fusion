package com.cg.banking.main;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.activity.InvalidActivityException;

import org.apache.log4j.PropertyConfigurator;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, SQLException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException, InvalidActivityException {

		PropertyConfigurator.configure("resources//log.properties");
		BankingServices bankingServices = new BankingServicesImpl();
		int accountNo = (int) bankingServices.openAccount("Savings", 2500);
		System.out.println(accountNo);
		int accountNo1=(int) bankingServices.openAccount("Savings", 3000);
		System.out.println(accountNo1);
		int accountNo2=(int) bankingServices.openAccount("Savings", 6000);
		System.out.println(accountNo2);
		
		System.out.println("Balance after deposit of 2000, "+bankingServices.depositAmount(1001, 2000));
		System.out.println("Post Withdrawal balance "+bankingServices.withdrawAmount(1002, 10, 1234));
		bankingServices.fundTransfer(1001, 1003, 10, 1234);
		System.out.println("Funds Transferred");
		Account getAccount=bankingServices.getAccountDetails(1001);
		System.out.println(getAccount.toString());

		ArrayList<Account> accountList = (ArrayList<Account>) bankingServices.getAllAccountDetails();
		System.out.println("All Account Details");
		for (Account account : accountList) {
			System.out.println(account.toString());
		}
		ArrayList<Transaction> accountTransactionList = (ArrayList<Transaction>) bankingServices.getAccountAllTransaction(1001);
		System.out.println("Transactions on Account "+1001);
		for (Transaction transaction : accountTransactionList)
			System.out.println(transaction.toString());
		System.out.println("Account status of "+1001 +" is "+bankingServices.accountStatus(1001));

	}
}
