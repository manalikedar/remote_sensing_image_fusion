import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;


public class MainClass7_1 {

	public static void main(String[] args) {
		String[] stringArray = {"Shampoo","Soap","Hairoil","Maggie"};
		for (String string : stringArray) {
			System.out.println(string);
		}
		Arrays.sort(stringArray);
		System.out.println("\nSorted array");
		for (String string : stringArray) {
			System.out.println(string);
		}
		ArrayList<String>stringArrayList = new ArrayList<>();
		stringArrayList.add("Shampoo");
		stringArrayList.add("Soap");
		stringArrayList.add("Hairoil");
		stringArrayList.add("Maggie");
		System.out.println("\nArray List\n"+stringArrayList.toString());
		Collections.sort(stringArrayList);
		System.out.println("Sorted Array\n ");
		for (String string : stringArrayList) {
			System.out.println(string);
		}
		
	}

}
