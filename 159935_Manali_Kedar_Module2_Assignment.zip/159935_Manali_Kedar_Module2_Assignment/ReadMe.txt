Lab 5-8 is implemented as CgEmployee Medical Insurance Scheme 

--
Lab 9-12 are implemented in CgBankingSystem Case Study( The Case Study was given by Satish Sir)