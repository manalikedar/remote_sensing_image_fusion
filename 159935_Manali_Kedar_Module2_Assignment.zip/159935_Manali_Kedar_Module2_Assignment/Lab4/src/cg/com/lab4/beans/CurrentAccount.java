package cg.com.lab4.beans;

public class CurrentAccount extends Account{
	private double overDraftLimit = 50000;
	public CurrentAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deposit(double amt) {
		this.setBalance(this.getBalance()+amt);
		
	}

	@Override
	public void withdraw(double amt) {
		if(amt-this.getBalance()<overDraftLimit){
			this.setBalance(this.getBalance()-amt);
			System.out.println("Withdrawal Successful");
		}
		else
			System.out.println("Limit Reached, transaction failed");
			
	}

	@Override
	public double calculateBalance() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
