package cg.com.lab4.client;

import cg.com.lab4.beans.CurrentAccount;
import cg.com.lab4.beans.Person;
import cg.com.lab4.beans.SavingsAccount;

public class MainClass {

	public static void main(String[] args) {
		Person person1 = new Person("Smith", 25);
		Person person2 = new Person("Kathy", 30);
		SavingsAccount savingsAccount = new SavingsAccount(2000, person1);
		SavingsAccount savingsAccount1 = new SavingsAccount(3000, person2);
		System.out.println(savingsAccount.getAccNum());
		savingsAccount.deposit(2000);
		System.out.println(savingsAccount.getBalance());
		savingsAccount1.withdraw(2000);
		System.out.println("Smith "+ savingsAccount.getBalance());
		System.out.println("Kathy Acc num "+savingsAccount1.getAccNum());
		System.out.println("Kathy "+savingsAccount1.getBalance());
		System.out.println("Current Account");
		CurrentAccount c1 = new CurrentAccount(5000, person1);
		c1.deposit(500);
		c1.withdraw(1200);
		System.out.println(savingsAccount.toString());

	}

}
